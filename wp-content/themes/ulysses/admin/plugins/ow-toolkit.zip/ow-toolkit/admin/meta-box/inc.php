<?php
require_once( dirname( __FILE__ ) . '/post_metabox.php' );
require_once( dirname( __FILE__ ) . '/page_metabox.php' );require_once( dirname( __FILE__ ) . '/product_metabox.php' );
require_once( dirname( __FILE__ ) . '/plan_metabox.php' );
require_once( dirname( __FILE__ ) . '/slider_metabox.php' );
require_once( dirname( __FILE__ ) . '/classes_metabox.php' );
require_once( dirname( __FILE__ ) . '/trainers_metabox.php' );
require_once( dirname( __FILE__ ) . '/portfolio_metabox.php' );
require_once( dirname( __FILE__ ) . '/testimonials_metabox.php' );